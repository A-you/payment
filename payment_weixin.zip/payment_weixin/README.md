# payment_weixin
weixin pay for odoo

![image](https://cloud.githubusercontent.com/assets/1404460/26557810/bf215548-44d6-11e7-9db7-d124cab3413e.png)


this module still in development, use it in production on your own risk

any feedback should be thankful.

if you want technical support, please contact the author and check the link http://item.taobao.com/item.htm?spm=a1z10.1-c.w4004-10020970078.16.EvfHHC&id=44624969034
